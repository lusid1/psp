This is a signed version of pspcomics homebrew it�s edited to start from the xmb digital comics icon.

installation:
copy .pspcomic floder to the root of your memorystick
copy NPEG00012 floder to \PSP\APP       (not GAME;)