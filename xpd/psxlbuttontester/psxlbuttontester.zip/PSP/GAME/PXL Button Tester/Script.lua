--[[

App Title: Button Tester
By: PixelOverfl0w

LUA Interpreter: ONElua v4R1

Script Description: Splash screen fade script.

--]]

--Colours
Black = color.new(0, 0, 0)


--Loading Images
SplashScreenImage = image.load("Images/SplashScreen.png")


--Loading Sounds
--BgMusic = sound.load("Sounds/BgMusic.mp3")
--sound.loop(BgMusic)

PXLSplashScreenSound = sound.load("Sounds/PXLSplashScreen.mp3")


--Fade Variables
Alpha = 1
PauseCounter = 0
FadeColour = Black

--Play First Splash Screen Sound As Application Starts
sound.play(PXLSplashScreenSound)

--Main Loop
while true do

--Enable Control Input
buttons.read()

--Clear Screen With Fade Colour
screen.clear(FadeColour)

--Display Splash Screen Image
image.blit(SplashScreenImage, 0, 0, Alpha)


--Fade Logic

--Start Fade
Alpha = Alpha + 2.5

--Pause When at Full Opacity
	if Alpha >= 255 then
		Alpha = 255
		PauseCounter = PauseCounter + 1
	end

--Pause for 50 Frames
	if PauseCounter >= 50 then
		Alpha = Alpha - 5
	end

--Exit Once Fade is Over
	if Alpha <= 0 then
		--sound.play(BgMusic)
		PXLSplashScreenSound = nil
		dofile("Scripts/ButtonTester.lua")
	end


--Skip Splash Screen
	if buttons.cross or buttons.circle or buttons.start then
		PXLSplashScreenSound = nil
		dofile("Scripts/ButtonTester.lua")
	end


--Display on Screen
screen.flip()

--End Main Loop
end
