--[[

App Title: Button Tester
By: PixelOverfl0w

LUA Interpreter: ONElua v4R1


Description:

It's a button tester, for testing buttons! :D

--]]

--Colours
Red = color.new(255, 0, 0)
Green = color.new(0, 200, 0)
Yellow = color.new(202, 213, 26)
MintGreen = color.new(0, 211, 134)
Pink = color.new(233, 52, 154)
Purple = color.new(170, 0, 226)


--Load Images

--Background
BackgroundImage = image.load("Images/Background.png")
BackgroundPSPImage= image.load("Images/BackgroundPSP.png")

TitleTextImage = image.load("Images/TitleText.png")

--Moving Background Symbols
BackgroundSquareButtonImage = image.load("Images/BackgroundSquare.png")
BackgroundSquare2Image = image.load("Images/BackgroundSquare.png")
BackgroundSquare3Image = image.load("Images/BackgroundSquare.png")

BackgroundCircleImage = image.load("Images/BackgroundCircle.png")
BackgroundCircle2Image = image.load("Images/BackgroundCircle.png")
BackgroundCircle3Image = image.load("Images/BackgroundCircle.png")

BackgroundTriangleImage = image.load("Images/BackgroundTriangle.png")
BackgroundTriangle2Image = image.load("Images/BackgroundTriangle.png")
BackgroundTriangle3Image = image.load("Images/BackgroundTriangle.png")

BackgroundCrossImage = image.load("Images/BackgroundCross.png")
BackgroundCross2Image = image.load("Images/BackgroundCross.png")
BackgroundCross3Image = image.load("Images/BackgroundCross.png")


--Button Tester Button Images

--Dpad Images
DpadLeftImage = image.load("Images/DpadLeft.png")
DpadRightImage = image.load("Images/DpadRight.png")
DpadUpImage = image.load("Images/DpadUp.png")
DpadDownImage = image.load("Images/DpadDown.png")

--Symbol Button Images
SquareButtonImage = image.load("Images/SquareButton.png")
CircleImage = image.load("Images/CircleButton.png")
TriangleImage = image.load("Images/TriangleButton.png")
CrossImage = image.load("Images/CrossButton.png")

--Trigger Button Images
LeftTriggerImage = image.load("Images/LeftTrigger.png")
RightTriggerImage = image.load("Images/RightTrigger.png")

--Home Button Strip Images
VolumeDownButtonImage = image.load("Images/VolumeDownButton.png")
VolumeUpButtonImage = image.load("Images/VolumeUpButton.png")
ScreenButtonImage = image.load("Images/ScreenButton.png")
NoteButtonImage = image.load("Images/NoteButton.png")
SelectButtonImage = image.load("Images/SelectButton.png")
StartButtonImage = image.load("Images/StartButton.png")

--Thumbstick Images
ThumbstickImage = image.load("Images/Thumbstick.png")
ThumbstickHighlightedImage = image.load("Images/ThumbstickHighlighted.png")

CursorImage = image.load("Images/Cursor.png")

--WLAN Icon
--WLANIconImage = image.load("Images/WLANIcon.png")
WLANIconPart1Image = image.load("Images/WLANIconPart1.png")
WLANIconPart2Image = image.load("Images/WLANIconPart2.png")
WLANIconPart3Image = image.load("Images/WLANIconPart3.png")

--Hold Icon
HoldIconImage = image.load("Images/HoldIcon.png")

--Tick Icon
TickIconImage = image.load("Images/TickIcon.png")

--Mute Icon
MuteIconImage = image.load("Images/MuteIcon.png")


--Load Sounds
DpadPressedSound = sound.load("Sounds/DpadPressed.mp3")
DpadReleasedSound = sound.load("Sounds/DpadReleased.mp3")

SymbolsPressedSound = sound.load("Sounds/SymbolsPressed.mp3")
SymbolsReleasedSound = sound.load("Sounds/SymbolsReleased.mp3")

TriggerPressedSound = sound.load("Sounds/TriggerPressed.mp3")
TriggerReleasedSound = sound.load("Sounds/TriggerReleased.mp3")

SelectStartPressedSound = sound.load("Sounds/SelectStartPressed.mp3")
SelectStartReleasedSound = sound.load("Sounds/SelectStartReleased.mp3")


--Tables

--Title Text
TitleText = {
	X = 70,
	Y = 35,
	Scale = 100,
	ScaleCounter = 1,
	Rotation = -19
}


--Screen Boundary
ScreenBoundary = {
	XMin = 0,
	XMax = 480,
	YMin = 0,
	YMax = 272
}


--Help Text Animation
HelpText = {
	Press_X = 169,
	Press_Y = 233,
	Any_X = 219,
	Any_Y = 233,
	Button_X = 253,
	Button_Y = 233,
	Counter = 0
}


--Thumbstick Tester Cursor
Cursor = {
	X = 232,
	Y = 132,
	ImageWidth = image.getw(CursorImage),
	ImageHeight = image.geth(CursorImage)
}

--Highlighted Thumbstick
Thumbstick = {
	Image = ThumbstickImage,
	X = 71,
	Y = 167
}

--Checklist
Checklist = {
	LeftTrigger = 0, -- 0 = not checked, 1 = checked off
	RightTrigger = 0,
	Left =  0,
	Right = 0,
	Up = 0,
	Down = 0,
	Square = 0,
	Circle = 0,
	Triangle = 0,
	Cross = 0,
	Select = 0,
	Start = 0,
	VolDown = 0,
	VolUp = 0,
	Screen = 0,
	Note = 0,
	WLAN = 0,
	Hold = 0
}

--Reset
Reset = {
	Counter = 0
}

--All Buttons Checked Animation Counter
AllButtonsCheckedText = {
	Counter = 0
}

--[[
--WLAN Icon Animation
WLANIconAnimation = {
	Counter = 0
}
--]]

--Moving Background Symbols

--Background Square 1
BackgroundSquare = {
X = math.random(0, 400),
Y = math.random(0, 240),
ImageWidth = image.getw(BackgroundSquareButtonImage),
ImageHeight = image.geth(BackgroundSquareButtonImage),
XDirection = math.random(2), --1 = negative direction, 2 = positive direction
YDirection = math.random(2), --1 = negative direction, 2 = positive direction
SpeedOption = math.random(3),
RotationDirection = math.random(2), --1 = negative direction, 2 = positive direction
RotationSpeed = math.random(4),
RotationDegrees = 0,
Scale = math.random(50, 110)
}

--Background Square 2 
BackgroundSquare2 = {
X = math.random(0, 400),
Y = math.random(0, 240),
ImageWidth = image.getw(BackgroundSquare2Image),
ImageHeight = image.geth(BackgroundSquare2Image),
XDirection = math.random(2), --1 = negative direction, 2 = positive direction
YDirection = math.random(2), --1 = negative direction, 2 = positive direction
SpeedOption = math.random(3),
RotationDirection = math.random(2), --1 = negative direction, 2 = positive direction
RotationSpeed = math.random(4),
RotationDegrees = 0,
Scale = math.random(50, 110)
}

--Background Square 3
BackgroundSquare3 = {
X = math.random(0, 400),
Y = math.random(0, 240),
ImageWidth = image.getw(BackgroundSquare3Image),
ImageHeight = image.geth(BackgroundSquare3Image),
XDirection = math.random(2), --1 = negative direction, 2 = positive direction
YDirection = math.random(2), --1 = negative direction, 2 = positive direction
SpeedOption = math.random(3),
RotationDirection = math.random(2), --1 = negative direction, 2 = positive direction
RotationSpeed = math.random(4),
RotationDegrees = 0,
Scale = math.random(50, 110)
}


--Background Circle 1
BackgroundCircle = {
X = math.random(0, 400),
Y = math.random(0, 240),
ImageWidth = image.getw(BackgroundCircleImage),
ImageHeight = image.geth(BackgroundCircleImage),
XDirection = math.random(2), --1 = negative direction, 2 = positive direction
YDirection = math.random(2), --1 = negative direction, 2 = positive direction
SpeedOption = math.random(3),
RotationDirection = math.random(2), --1 = negative direction, 2 = positive direction
RotationSpeed = math.random(4),
RotationDegrees = 0,
Scale = math.random(50, 110)
}

--Background Circle 2 
BackgroundCircle2 = {
X = math.random(0, 400),
Y = math.random(0, 240),
ImageWidth = image.getw(BackgroundCircle2Image),
ImageHeight = image.geth(BackgroundCircle2Image),
XDirection = math.random(2), --1 = negative direction, 2 = positive direction
YDirection = math.random(2), --1 = negative direction, 2 = positive direction
SpeedOption = math.random(3),
RotationDirection = math.random(2), --1 = negative direction, 2 = positive direction
RotationSpeed = math.random(4),
RotationDegrees = 0,
Scale = math.random(50, 110)
}

--Background Circle 3
BackgroundCircle3 = {
X = math.random(0, 400),
Y = math.random(0, 240),
ImageWidth = image.getw(BackgroundCircle3Image),
ImageHeight = image.geth(BackgroundCircle3Image),
XDirection = math.random(2), --1 = negative direction, 2 = positive direction
YDirection = math.random(2), --1 = negative direction, 2 = positive direction
SpeedOption = math.random(3),
RotationDirection = math.random(2), --1 = negative direction, 2 = positive direction
RotationSpeed = math.random(4),
RotationDegrees = 0,
Scale = math.random(50, 110)
}


--Background Triangle 1
BackgroundTriangle = {
X = math.random(0, 400),
Y = math.random(0, 240),
ImageWidth = image.getw(BackgroundTriangleImage),
ImageHeight = image.geth(BackgroundTriangleImage),
XDirection = math.random(2), --1 = negative direction, 2 = positive direction
YDirection = math.random(2), --1 = negative direction, 2 = positive direction
SpeedOption = math.random(3),
RotationDirection = math.random(2), --1 = negative direction, 2 = positive direction
RotationSpeed = math.random(4),
RotationDegrees = 0,
Scale = math.random(50, 110)
}

--Background Triangle 2
BackgroundTriangle2 = {
X = math.random(0, 400),
Y = math.random(0, 240),
ImageWidth = image.getw(BackgroundTriangle2Image),
ImageHeight = image.geth(BackgroundTriangle2Image),
XDirection = math.random(2), --1 = negative direction, 2 = positive direction
YDirection = math.random(2), --1 = negative direction, 2 = positive direction
SpeedOption = math.random(3),
RotationDirection = math.random(2), --1 = negative direction, 2 = positive direction
RotationSpeed = math.random(4),
RotationDegrees = 0,
Scale = math.random(50, 110)
}

--Background Triangle 3
BackgroundTriangle3 = {
X = math.random(0, 400),
Y = math.random(0, 240),
ImageWidth = image.getw(BackgroundTriangle3Image),
ImageHeight = image.geth(BackgroundTriangle3Image),
XDirection = math.random(2), --1 = negative direction, 2 = positive direction
YDirection = math.random(2), --1 = negative direction, 2 = positive direction
SpeedOption = math.random(3),
RotationDirection = math.random(2), --1 = negative direction, 2 = positive direction
RotationSpeed = math.random(4),
RotationDegrees = 0,
Scale = math.random(50, 110)
}


--Background Cross 1
BackgroundCross = {
X = math.random(0, 400),
Y = math.random(0, 240),
ImageWidth = image.getw(BackgroundCrossImage),
ImageHeight = image.geth(BackgroundCrossImage),
XDirection = math.random(2), --1 = negative direction, 2 = positive direction
YDirection = math.random(2), --1 = negative direction, 2 = positive direction
SpeedOption = math.random(3),
RotationDirection = math.random(2), --1 = negative direction, 2 = positive direction
RotationSpeed = math.random(4),
RotationDegrees = 0,
Scale = math.random(50, 110)
}

--Background Cross 2
BackgroundCross2 = {
X = math.random(0, 400),
Y = math.random(0, 240),
ImageWidth = image.getw(BackgroundCross2Image),
ImageHeight = image.geth(BackgroundCross2Image),
XDirection = math.random(2), --1 = negative direction, 2 = positive direction
YDirection = math.random(2), --1 = negative direction, 2 = positive direction
SpeedOption = math.random(3),
RotationDirection = math.random(2), --1 = negative direction, 2 = positive direction
RotationSpeed = math.random(4),
RotationDegrees = 0,
Scale = math.random(50, 110)
}

--Background Cross 3
BackgroundCross3 = {
X = math.random(0, 400),
Y = math.random(0, 240),
ImageWidth = image.getw(BackgroundCross3Image),
ImageHeight = image.geth(BackgroundCross3Image),
XDirection = math.random(2), --1 = negative direction, 2 = positive direction
YDirection = math.random(2), --1 = negative direction, 2 = positive direction
SpeedOption = math.random(3),
RotationDirection = math.random(2), --1 = negative direction, 2 = positive direction
RotationSpeed = math.random(4),
RotationDegrees = 0,
Scale = math.random(50, 110)
}


--Variables

WLANIconAnimation_Counter = 0


--Unmute PSP
--Without this command, if the PSP is muted when booting the program, the note button test will already be passed, which isn't very useful.
hw.mute(0)


--Main Loop
while true do

--Begin Reading Buttons
buttons.read()

--Prevent System Sleep
--Required to stop the system from sleeping when testing the thumbstick, as moving thethumbstick does not prevent the system from sleeping.
power.tick ()


--Display Background Image
image.blit(BackgroundImage, 0, 0)

--Display Moving Backgroud Symbols

--Square 1
image.center(BackgroundSquareButtonImage)
image.scale(BackgroundSquareButtonImage, BackgroundSquare.Scale)
image.rotate(BackgroundSquareButtonImage, BackgroundSquare.RotationDegrees)
image.blit(BackgroundSquareButtonImage, BackgroundSquare.X, BackgroundSquare.Y)

--Square 2
image.center(BackgroundSquare2Image)
image.scale(BackgroundSquare2Image, BackgroundSquare2.Scale)
image.rotate(BackgroundSquare2Image, BackgroundSquare2.RotationDegrees)
image.blit(BackgroundSquare2Image, BackgroundSquare2.X, BackgroundSquare2.Y)

--Square 3
image.center(BackgroundSquare3Image)
image.scale(BackgroundSquare3Image, BackgroundSquare3.Scale)
image.rotate(BackgroundSquare3Image, BackgroundSquare3.RotationDegrees)
image.blit(BackgroundSquare3Image, BackgroundSquare3.X, BackgroundSquare3.Y)


--Circle 1
image.center(BackgroundCircleImage)
image.scale(BackgroundCircleImage, BackgroundCircle.Scale)
image.rotate(BackgroundCircleImage, BackgroundCircle.RotationDegrees)
image.blit(BackgroundCircleImage, BackgroundCircle.X, BackgroundCircle.Y)

--Circle 2
image.center(BackgroundCircle2Image)
image.scale(BackgroundCircle2Image, BackgroundCircle2.Scale)
image.rotate(BackgroundCircle2Image, BackgroundCircle2.RotationDegrees)
image.blit(BackgroundCircle2Image, BackgroundCircle2.X, BackgroundCircle2.Y)

--Circle 3
image.center(BackgroundCircle3Image)
image.scale(BackgroundCircle3Image, BackgroundCircle3.Scale)
image.rotate(BackgroundCircle3Image, BackgroundCircle3.RotationDegrees)
image.blit(BackgroundCircle3Image, BackgroundCircle3.X, BackgroundCircle3.Y)


--Triangle 1
image.center(BackgroundTriangleImage)
image.scale(BackgroundTriangleImage, BackgroundTriangle.Scale)
image.rotate(BackgroundTriangleImage, BackgroundTriangle.RotationDegrees)
image.blit(BackgroundTriangleImage, BackgroundTriangle.X, BackgroundTriangle.Y)

--Triangle 2
image.center(BackgroundTriangle2Image)
image.scale(BackgroundTriangle2Image, BackgroundTriangle2.Scale)
image.rotate(BackgroundTriangle2Image, BackgroundTriangle2.RotationDegrees)
image.blit(BackgroundTriangle2Image, BackgroundTriangle2.X, BackgroundTriangle2.Y)

--Triangle 3
image.center(BackgroundTriangle3Image)
image.scale(BackgroundTriangle3Image, BackgroundTriangle3.Scale)
image.rotate(BackgroundTriangle3Image, BackgroundTriangle3.RotationDegrees)
image.blit(BackgroundTriangle3Image, BackgroundTriangle3.X, BackgroundTriangle3.Y)


--Cross 1
image.center(BackgroundCrossImage)
image.scale(BackgroundCrossImage, BackgroundCross.Scale)
image.rotate(BackgroundCrossImage, BackgroundCross.RotationDegrees)
image.blit(BackgroundCrossImage, BackgroundCross.X, BackgroundCross.Y)

--Cross 2
image.center(BackgroundCross2Image)
image.scale(BackgroundCross2Image, BackgroundCross2.Scale)
image.rotate(BackgroundCross2Image, BackgroundCross2.RotationDegrees)
image.blit(BackgroundCross2Image, BackgroundCross2.X, BackgroundCross2.Y)

--Cross 3
image.center(BackgroundCross3Image)
image.scale(BackgroundCross3Image, BackgroundCross3.Scale)
image.rotate(BackgroundCross3Image, BackgroundCross3.RotationDegrees)
image.blit(BackgroundCross3Image, BackgroundCross3.X, BackgroundCross3.Y)


--PSP GUI Image
image.blit(BackgroundPSPImage, 0, 0)


function HelpTextAnimation()

--Display Help Text
screen.print(HelpText.Press_X, HelpText.Press_Y, "Press", 0.8, Pink)
screen.print(HelpText.Any_X, HelpText.Any_Y, "Any", 0.8, Pink)
screen.print(HelpText.Button_X, HelpText.Button_Y, "Button", 0.8, Pink)


--Help Text Animation Logic

HelpText.Counter = HelpText.Counter + 1


--Press
	if HelpText.Counter <= 15 then --Time allowed for text to travel
		HelpText.Press_Y = HelpText.Press_Y - 0.25 --Text Travel Speed

	elseif HelpText.Counter > 15 and HelpText.Counter <= 30 then
		HelpText.Press_Y = HelpText.Press_Y + 0.25
--Any
	elseif HelpText.Counter > 30 and HelpText.Counter <= 45 then
		HelpText.Any_Y = HelpText.Any_Y - 0.25

	elseif HelpText.Counter > 45 and HelpText.Counter <= 60 then
		HelpText.Any_Y = HelpText.Any_Y + 0.25

--Button
	elseif HelpText.Counter > 60 and HelpText.Counter <= 75 then
		HelpText.Button_Y = HelpText.Button_Y - 0.25

	elseif HelpText.Counter > 75 and HelpText.Counter <= 90 then
		HelpText.Button_Y = HelpText.Button_Y + 0.25
	end


--Pause and then Reset Counter Back to 0 to Restart Animation
	if HelpText.Counter > 135 then
		HelpText.Counter = 0
	end

--Function End
end


--All Buttons Checked Flashing Text

function AllButtonsCheckedTextFlash()

--Counter Logic
AllButtonsCheckedText.Counter = AllButtonsCheckedText.Counter + 1

	if AllButtonsCheckedText.Counter <= 30 then
		AllButtonsCheckedText.Colour = Green
	else AllButtonsCheckedText.Colour = Purple
	end

	if AllButtonsCheckedText.Counter >= 60 then
		AllButtonsCheckedText.Counter = 0
	end

screen.print(153, 233, "All Buttons Checked!", 0.8, AllButtonsCheckedText.Colour)

--Function End
end


	if Checklist.LeftTrigger +
		Checklist.RightTrigger +
		Checklist.Square +
		Checklist.Circle +
		Checklist.Triangle +
		Checklist.Cross +
		Checklist.Left +
		Checklist.Right +
		Checklist.Up +
		Checklist.Down +
		Checklist.Select +
		Checklist.Start +
		Checklist.VolDown +
		Checklist.VolUp +
		Checklist.Screen +
		Checklist.Note +
		Checklist.WLAN +
		Checklist.Hold < 18 then
		HelpTextAnimation()
	else AllButtonsCheckedTextFlash()
	end


--Display Screen Brightness
screen.print(290, 14, "Screen Brightness: " ..screen.brightness(), 0.7, Yellow)


--Display Volume Level
screen.print(315, 31, "Volume Level: " ..hw.volume(), 0.7, MintGreen)


--Display Cursor
image.blit(CursorImage, Cursor.X, Cursor.Y)


--Display Analog Data
screen.print(116, 180, "X: " ..buttons.analogx, 0.5)
screen.print(116, 190, "Y: " ..buttons.analogy, 0.5)


--Display Title Text Image
image.center(TitleTextImage)
image.rotate(TitleTextImage, TitleText.Rotation)
image.scale(TitleTextImage, TitleText.Scale)
image.blit(TitleTextImage, TitleText.X, TitleText.Y)


--Title Scaling Logic
TitleText.ScaleCounter = TitleText.ScaleCounter + 1

	if TitleText.ScaleCounter > 50 then
		TitleText.ScaleCounter = 1
	end

	if TitleText.ScaleCounter <= 25 then
		TitleText.Scale = TitleText.Scale + 0.5

	elseif TitleText.ScaleCounter > 25  then
		TitleText.Scale = TitleText.Scale - 0.5
	end


--Moving Background Symbols Logic

--Square 1 Moving Background Symbol Logic

--Square 1 Movement Speed
	if BackgroundSquare.SpeedOption == 1 then
		BackgroundSquare.Speed = 0.7
	
	elseif BackgroundSquare.SpeedOption == 2 then
		BackgroundSquare.Speed = 1

	elseif BackgroundSquare.SpeedOption == 3 then
		BackgroundSquare.Speed = 1.2
	end
		

--Square 1: X Movement
	if BackgroundSquare.XDirection == 1 then
		BackgroundSquare.X = (BackgroundSquare.X - BackgroundSquare.Speed)

	elseif BackgroundSquare.XDirection == 2 then
		BackgroundSquare.X = (BackgroundSquare.X + BackgroundSquare.Speed)
	end

-- Square 1: X Direction Swap
	if BackgroundSquare.X <= (ScreenBoundary.XMin + (BackgroundSquare.ImageWidth /2)) then
		BackgroundSquare.XDirection = 2

	elseif BackgroundSquare.X >= (ScreenBoundary.XMax - (BackgroundSquare.ImageWidth /2)) then
		BackgroundSquare.XDirection = 1
	end

--Square 1: Y Movement
	if BackgroundSquare.YDirection == 1 then
		BackgroundSquare.Y = (BackgroundSquare.Y - BackgroundSquare.Speed)

	elseif BackgroundSquare.YDirection == 2 then
		BackgroundSquare.Y = (BackgroundSquare.Y + BackgroundSquare.Speed)
	end

--Square 1: Y Direction Swap
	if BackgroundSquare.Y <= (ScreenBoundary.YMin + (BackgroundSquare.ImageHeight /2)) then
		BackgroundSquare.YDirection = 2

	elseif BackgroundSquare.Y >= (ScreenBoundary.YMax - (BackgroundSquare.ImageHeight /2)) then
		BackgroundSquare.YDirection = 1
	end

--Square 1 Rotation

	if BackgroundSquare.RotationDirection == 1 then
		BackgroundSquare.RotationDegrees = (BackgroundSquare.RotationDegrees - BackgroundSquare.RotationSpeed)
		
	elseif BackgroundSquare.RotationDirection == 2 then
		BackgroundSquare.RotationDegrees = (BackgroundSquare.RotationDegrees + BackgroundSquare.RotationSpeed)
	end

	if BackgroundSquare.RotationDegrees > 360 then
		BackgroundSquare.RotationDegrees = 0
	end

	if BackgroundSquare.RotationDegrees < -360 then
		BackgroundSquare.RotationDegrees = 0
	end

--Make Square 1 rotation direction follow X direction, for more /slightly/ more accurate physics
	if BackgroundSquare.XDirection == 1 then
		BackgroundSquare.RotationDirection = 1
	end

	if BackgroundSquare.XDirection == 2 then
		BackgroundSquare.RotationDirection = 2
	end


--Square 2 Moving Background Symbol Logic

--Square 2 Movement Speed
	if BackgroundSquare2.SpeedOption == 1 then
		BackgroundSquare2.Speed = 0.7
	
	elseif BackgroundSquare2.SpeedOption == 2 then
		BackgroundSquare2.Speed = 1

	elseif BackgroundSquare2.SpeedOption == 3 then
		BackgroundSquare2.Speed = 1.2
	end


--Square 2: X Movement
	if BackgroundSquare2.XDirection == 1 then
		BackgroundSquare2.X = (BackgroundSquare2.X - BackgroundSquare2.Speed)

	elseif BackgroundSquare2.XDirection == 2 then
		BackgroundSquare2.X = (BackgroundSquare2.X + BackgroundSquare2.Speed)
	end

-- Square 2: X Direction Swap
	if BackgroundSquare2.X <= (ScreenBoundary.XMin + (BackgroundSquare2.ImageWidth /2)) then
		BackgroundSquare2.XDirection = 2

	elseif BackgroundSquare2.X >= (ScreenBoundary.XMax - (BackgroundSquare2.ImageWidth /2)) then
		BackgroundSquare2.XDirection = 1
	end

--Square 2: Y Movement
	if BackgroundSquare2.YDirection == 1 then
		BackgroundSquare2.Y = (BackgroundSquare2.Y - BackgroundSquare2.Speed)

	elseif BackgroundSquare2.YDirection == 2 then
		BackgroundSquare2.Y = (BackgroundSquare2.Y + BackgroundSquare2.Speed)
	end

--Square 2: Y Direction Swap
	if BackgroundSquare2.Y <= (ScreenBoundary.YMin + (BackgroundSquare2.ImageHeight /2)) then
		BackgroundSquare2.YDirection = 2

	elseif BackgroundSquare2.Y >= (ScreenBoundary.YMax - (BackgroundSquare2.ImageHeight /2)) then
		BackgroundSquare2.YDirection = 1
	end

--Square 2 Rotation

	if BackgroundSquare2.RotationDirection == 1 then
		BackgroundSquare2.RotationDegrees = (BackgroundSquare2.RotationDegrees - BackgroundSquare2.RotationSpeed)
		
	elseif BackgroundSquare2.RotationDirection == 2 then
		BackgroundSquare2.RotationDegrees = (BackgroundSquare2.RotationDegrees + BackgroundSquare2.RotationSpeed)
	end

	if BackgroundSquare2.RotationDegrees > 360 then
		BackgroundSquare2.RotationDegrees = 0
	end

	if BackgroundSquare2.RotationDegrees < -360 then
		BackgroundSquare2.RotationDegrees = 0
	end

--Make Square 2 rotation direction follow X direction, for more /slightly/ more accurate physics
	if BackgroundSquare2.XDirection == 1 then
		BackgroundSquare2.RotationDirection = 1
	end

	if BackgroundSquare2.XDirection == 2 then
		BackgroundSquare2.RotationDirection = 2
	end


--Square 3 Moving Background Symbol Logic

--Square 3 Movement Speed
	if BackgroundSquare3.SpeedOption == 1 then
		BackgroundSquare3.Speed = 0.7
	
	elseif BackgroundSquare3.SpeedOption == 2 then
		BackgroundSquare3.Speed = 1

	elseif BackgroundSquare3.SpeedOption == 3 then
		BackgroundSquare3.Speed = 1.2
	end


--Square 3: X Movement
	if BackgroundSquare3.XDirection == 1 then
		BackgroundSquare3.X = (BackgroundSquare3.X - BackgroundSquare3.Speed)

	elseif BackgroundSquare3.XDirection == 2 then
		BackgroundSquare3.X = (BackgroundSquare3.X + BackgroundSquare3.Speed)
	end

-- Square 3: X Direction Swap
	if BackgroundSquare3.X <= (ScreenBoundary.XMin + (BackgroundSquare3.ImageWidth /2)) then
		BackgroundSquare3.XDirection = 2

	elseif BackgroundSquare3.X >= (ScreenBoundary.XMax - (BackgroundSquare3.ImageWidth /2)) then
		BackgroundSquare3.XDirection = 1
	end

--Square 3: Y Movement
	if BackgroundSquare3.YDirection == 1 then
		BackgroundSquare3.Y = (BackgroundSquare3.Y - BackgroundSquare3.Speed)

	elseif BackgroundSquare3.YDirection == 2 then
		BackgroundSquare3.Y = (BackgroundSquare3.Y + BackgroundSquare3.Speed)
	end

--Square 3: Y Direction Swap
	if BackgroundSquare3.Y <= (ScreenBoundary.YMin + (BackgroundSquare3.ImageHeight /2)) then
		BackgroundSquare3.YDirection = 2

	elseif BackgroundSquare3.Y >= (ScreenBoundary.YMax - (BackgroundSquare3.ImageHeight /2)) then
		BackgroundSquare3.YDirection = 1
	end

--Square 3 Rotation

	if BackgroundSquare3.RotationDirection == 1 then
		BackgroundSquare3.RotationDegrees = (BackgroundSquare3.RotationDegrees - BackgroundSquare3.RotationSpeed)
		
	elseif BackgroundSquare3.RotationDirection == 2 then
		BackgroundSquare3.RotationDegrees = (BackgroundSquare3.RotationDegrees + BackgroundSquare3.RotationSpeed)
	end

	if BackgroundSquare3.RotationDegrees > 360 then
		BackgroundSquare3.RotationDegrees = 0
	end

	if BackgroundSquare3.RotationDegrees < -360 then
		BackgroundSquare3.RotationDegrees = 0
	end

--Make Square 3 rotation direction follow X direction, for more /slightly/ more accurate physics
	if BackgroundSquare3.XDirection == 1 then
		BackgroundSquare3.RotationDirection = 1
	end

	if BackgroundSquare3.XDirection == 2 then
		BackgroundSquare3.RotationDirection = 2
	end


--Circle 1 Moving Background Symbol Logic

--Circle 1 Movement Speed
	if BackgroundCircle.SpeedOption == 1 then
		BackgroundCircle.Speed = 0.7
	
	elseif BackgroundCircle.SpeedOption == 2 then
		BackgroundCircle.Speed = 1

	elseif BackgroundCircle.SpeedOption == 3 then
		BackgroundCircle.Speed = 1.2
	end


--Circle 1: X Movement
	if BackgroundCircle.XDirection == 1 then
		BackgroundCircle.X = (BackgroundCircle.X - BackgroundCircle.Speed)

	elseif BackgroundCircle.XDirection == 2 then
		BackgroundCircle.X = (BackgroundCircle.X + BackgroundCircle.Speed)
	end

-- Circle 1: X Direction Swap
	if BackgroundCircle.X <= (ScreenBoundary.XMin + (BackgroundCircle.ImageWidth /2)) then
		BackgroundCircle.XDirection = 2

	elseif BackgroundCircle.X >= (ScreenBoundary.XMax - (BackgroundCircle.ImageWidth /2)) then
		BackgroundCircle.XDirection = 1
	end

--Circle 1: Y Movement
	if BackgroundCircle.YDirection == 1 then
		BackgroundCircle.Y = (BackgroundCircle.Y - BackgroundCircle.Speed)

	elseif BackgroundCircle.YDirection == 2 then
		BackgroundCircle.Y = (BackgroundCircle.Y + BackgroundCircle.Speed)
	end

--Circle 1: Y Direction Swap
	if BackgroundCircle.Y <= (ScreenBoundary.YMin + (BackgroundCircle.ImageHeight /2)) then
		BackgroundCircle.YDirection = 2

	elseif BackgroundCircle.Y >= (ScreenBoundary.YMax - (BackgroundCircle.ImageHeight /2)) then
		BackgroundCircle.YDirection = 1
	end

--Circle 1 Rotation

	if BackgroundCircle.RotationDirection == 1 then
		BackgroundCircle.RotationDegrees = (BackgroundCircle.RotationDegrees - BackgroundCircle.RotationSpeed)
		
	elseif BackgroundCircle.RotationDirection == 2 then
		BackgroundCircle.RotationDegrees = (BackgroundCircle.RotationDegrees + BackgroundCircle.RotationSpeed)
	end

	if BackgroundCircle.RotationDegrees > 360 then
		BackgroundCircle.RotationDegrees = 0
	end

	if BackgroundCircle.RotationDegrees < -360 then
		BackgroundCircle.RotationDegrees = 0
	end

--Make Circle 1 rotation direction follow X direction, for more /slightly/ more accurate physics
	if BackgroundCircle.XDirection == 1 then
		BackgroundCircle.RotationDirection = 1
	end

	if BackgroundCircle.XDirection == 2 then
		BackgroundCircle.RotationDirection = 2
	end


--Circle 2 Moving Background Symbol Logic

--Circle 2 Movement Speed
	if BackgroundCircle2.SpeedOption == 1 then
		BackgroundCircle2.Speed = 0.7
	
	elseif BackgroundCircle2.SpeedOption == 2 then
		BackgroundCircle2.Speed = 1

	elseif BackgroundCircle2.SpeedOption == 3 then
		BackgroundCircle2.Speed = 1.2
	end


--Circle 2: X Movement
	if BackgroundCircle2.XDirection == 1 then
		BackgroundCircle2.X = (BackgroundCircle2.X - BackgroundCircle2.Speed)

	elseif BackgroundCircle2.XDirection == 2 then
		BackgroundCircle2.X = (BackgroundCircle2.X + BackgroundCircle2.Speed)
	end

-- Circle 2: X Direction Swap
	if BackgroundCircle2.X <= (ScreenBoundary.XMin + (BackgroundCircle2.ImageWidth /2)) then
		BackgroundCircle2.XDirection = 2

	elseif BackgroundCircle2.X >= (ScreenBoundary.XMax - (BackgroundCircle2.ImageWidth /2)) then
		BackgroundCircle2.XDirection = 1
	end

--Circle 2: Y Movement
	if BackgroundCircle2.YDirection == 1 then
		BackgroundCircle2.Y = (BackgroundCircle2.Y - BackgroundCircle2.Speed)

	elseif BackgroundCircle2.YDirection == 2 then
		BackgroundCircle2.Y = (BackgroundCircle2.Y + BackgroundCircle2.Speed)
	end

--Circle 2: Y Direction Swap
	if BackgroundCircle2.Y <= (ScreenBoundary.YMin + (BackgroundCircle2.ImageHeight /2)) then
		BackgroundCircle2.YDirection = 2

	elseif BackgroundCircle2.Y >= (ScreenBoundary.YMax - (BackgroundCircle2.ImageHeight /2)) then
		BackgroundCircle2.YDirection = 1
	end

--Circle 2 Rotation

	if BackgroundCircle2.RotationDirection == 1 then
		BackgroundCircle2.RotationDegrees = (BackgroundCircle2.RotationDegrees - BackgroundCircle2.RotationSpeed)
		
	elseif BackgroundCircle2.RotationDirection == 2 then
		BackgroundCircle2.RotationDegrees = (BackgroundCircle2.RotationDegrees + BackgroundCircle2.RotationSpeed)
	end

	if BackgroundCircle2.RotationDegrees > 360 then
		BackgroundCircle2.RotationDegrees = 0
	end

	if BackgroundCircle2.RotationDegrees < -360 then
		BackgroundCircle2.RotationDegrees = 0
	end

--Make Circle 2 rotation direction follow X direction, for more /slightly/ more accurate physics
	if BackgroundCircle2.XDirection == 1 then
		BackgroundCircle2.RotationDirection = 1
	end

	if BackgroundCircle2.XDirection == 2 then
		BackgroundCircle2.RotationDirection = 2
	end


--Circle 3 Moving Background Symbol Logic

--Circle 3 Movement Speed
	if BackgroundCircle3.SpeedOption == 1 then
		BackgroundCircle3.Speed = 0.7
	
	elseif BackgroundCircle3.SpeedOption == 2 then
		BackgroundCircle3.Speed = 1

	elseif BackgroundCircle3.SpeedOption == 3 then
		BackgroundCircle3.Speed = 1.2
	end


--Circle 3: X Movement
	if BackgroundCircle3.XDirection == 1 then
		BackgroundCircle3.X = (BackgroundCircle3.X - BackgroundCircle3.Speed)

	elseif BackgroundCircle3.XDirection == 2 then
		BackgroundCircle3.X = (BackgroundCircle3.X + BackgroundCircle3.Speed)
	end

-- Circle 3: X Direction Swap
	if BackgroundCircle3.X <= (ScreenBoundary.XMin + (BackgroundCircle3.ImageWidth /2)) then
		BackgroundCircle3.XDirection = 2

	elseif BackgroundCircle3.X >= (ScreenBoundary.XMax - (BackgroundCircle3.ImageWidth /2)) then
		BackgroundCircle3.XDirection = 1
	end

--Circle 3: Y Movement
	if BackgroundCircle3.YDirection == 1 then
		BackgroundCircle3.Y = (BackgroundCircle3.Y - BackgroundCircle3.Speed)

	elseif BackgroundCircle3.YDirection == 2 then
		BackgroundCircle3.Y = (BackgroundCircle3.Y + BackgroundCircle3.Speed)
	end

--Circle 3: Y Direction Swap
	if BackgroundCircle3.Y <= (ScreenBoundary.YMin + (BackgroundCircle3.ImageHeight /2)) then
		BackgroundCircle3.YDirection = 2

	elseif BackgroundCircle3.Y >= (ScreenBoundary.YMax - (BackgroundCircle3.ImageHeight /2)) then
		BackgroundCircle3.YDirection = 1
	end

--Circle 3 Rotation

	if BackgroundCircle3.RotationDirection == 1 then
		BackgroundCircle3.RotationDegrees = (BackgroundCircle3.RotationDegrees - BackgroundCircle3.RotationSpeed)
		
	elseif BackgroundCircle3.RotationDirection == 2 then
		BackgroundCircle3.RotationDegrees = (BackgroundCircle3.RotationDegrees + BackgroundCircle3.RotationSpeed)
	end

	if BackgroundCircle3.RotationDegrees > 360 then
		BackgroundCircle3.RotationDegrees = 0
	end

	if BackgroundCircle3.RotationDegrees < -360 then
		BackgroundCircle3.RotationDegrees = 0
	end

--Make Circle 3 rotation direction follow X direction, for more /slightly/ more accurate physics
	if BackgroundCircle3.XDirection == 1 then
		BackgroundCircle3.RotationDirection = 1
	end

	if BackgroundCircle3.XDirection == 2 then
		BackgroundCircle3.RotationDirection = 2
	end


--Triangle 1 Moving Background Symbol Logic

--Triangle 1 Movement Speed
	if BackgroundTriangle.SpeedOption == 1 then
		BackgroundTriangle.Speed = 0.7
	
	elseif BackgroundTriangle.SpeedOption == 2 then
		BackgroundTriangle.Speed = 1

	elseif BackgroundTriangle.SpeedOption == 3 then
		BackgroundTriangle.Speed = 1.2
	end


--Triangle 1: X Movement
	if BackgroundTriangle.XDirection == 1 then
		BackgroundTriangle.X = (BackgroundTriangle.X - BackgroundTriangle.Speed)

	elseif BackgroundTriangle.XDirection == 2 then
		BackgroundTriangle.X = (BackgroundTriangle.X + BackgroundTriangle.Speed)
	end

-- Triangle 1: X Direction Swap
	if BackgroundTriangle.X <= (ScreenBoundary.XMin + (BackgroundTriangle.ImageWidth /2)) then
		BackgroundTriangle.XDirection = 2

	elseif BackgroundTriangle.X >= (ScreenBoundary.XMax - (BackgroundTriangle.ImageWidth /2)) then
		BackgroundTriangle.XDirection = 1
	end

--Triangle 1: Y Movement
	if BackgroundTriangle.YDirection == 1 then
		BackgroundTriangle.Y = (BackgroundTriangle.Y - BackgroundTriangle.Speed)

	elseif BackgroundTriangle.YDirection == 2 then
		BackgroundTriangle.Y = (BackgroundTriangle.Y + BackgroundTriangle.Speed)
	end

--Triangle 1: Y Direction Swap
	if BackgroundTriangle.Y <= (ScreenBoundary.YMin + (BackgroundTriangle.ImageHeight /2)) then
		BackgroundTriangle.YDirection = 2

	elseif BackgroundTriangle.Y >= (ScreenBoundary.YMax - (BackgroundTriangle.ImageHeight /2)) then
		BackgroundTriangle.YDirection = 1
	end

--Triangle 1 Rotation

	if BackgroundTriangle.RotationDirection == 1 then
		BackgroundTriangle.RotationDegrees = (BackgroundTriangle.RotationDegrees - BackgroundTriangle.RotationSpeed)
		
	elseif BackgroundTriangle.RotationDirection == 2 then
		BackgroundTriangle.RotationDegrees = (BackgroundTriangle.RotationDegrees + BackgroundTriangle.RotationSpeed)
	end

	if BackgroundTriangle.RotationDegrees > 360 then
		BackgroundTriangle.RotationDegrees = 0
	end

	if BackgroundTriangle.RotationDegrees < -360 then
		BackgroundTriangle.RotationDegrees = 0
	end

--Make Triangle 1 rotation direction follow X direction, for more /slightly/ more accurate physics
	if BackgroundTriangle.XDirection == 1 then
		BackgroundTriangle.RotationDirection = 1
	end

	if BackgroundTriangle.XDirection == 2 then
		BackgroundTriangle.RotationDirection = 2
	end


--Triangle 2 Moving Background Symbol Logic

--Triangle 2 Movement Speed
	if BackgroundTriangle2.SpeedOption == 1 then
		BackgroundTriangle2.Speed = 0.7
	
	elseif BackgroundTriangle2.SpeedOption == 2 then
		BackgroundTriangle2.Speed = 1

	elseif BackgroundTriangle2.SpeedOption == 3 then
		BackgroundTriangle2.Speed = 1.2
	end


--Triangle 2: X Movement
	if BackgroundTriangle2.XDirection == 1 then
		BackgroundTriangle2.X = (BackgroundTriangle2.X - BackgroundTriangle2.Speed)

	elseif BackgroundTriangle2.XDirection == 2 then
		BackgroundTriangle2.X = (BackgroundTriangle2.X + BackgroundTriangle2.Speed)
	end

-- Triangle 2: X Direction Swap
	if BackgroundTriangle2.X <= (ScreenBoundary.XMin + (BackgroundTriangle2.ImageWidth /2)) then
		BackgroundTriangle2.XDirection = 2

	elseif BackgroundTriangle2.X >= (ScreenBoundary.XMax - (BackgroundTriangle2.ImageWidth /2)) then
		BackgroundTriangle2.XDirection = 1
	end

--Triangle 2: Y Movement
	if BackgroundTriangle2.YDirection == 1 then
		BackgroundTriangle2.Y = (BackgroundTriangle2.Y - BackgroundTriangle2.Speed)

	elseif BackgroundTriangle2.YDirection == 2 then
		BackgroundTriangle2.Y = (BackgroundTriangle2.Y + BackgroundTriangle2.Speed)
	end

--Triangle 2: Y Direction Swap
	if BackgroundTriangle2.Y <= (ScreenBoundary.YMin + (BackgroundTriangle2.ImageHeight /2)) then
		BackgroundTriangle2.YDirection = 2

	elseif BackgroundTriangle2.Y >= (ScreenBoundary.YMax - (BackgroundTriangle2.ImageHeight /2)) then
		BackgroundTriangle2.YDirection = 1
	end

--Triangle 2 Rotation

	if BackgroundTriangle2.RotationDirection == 1 then
		BackgroundTriangle2.RotationDegrees = (BackgroundTriangle2.RotationDegrees - BackgroundTriangle2.RotationSpeed)
		
	elseif BackgroundTriangle2.RotationDirection == 2 then
		BackgroundTriangle2.RotationDegrees = (BackgroundTriangle2.RotationDegrees + BackgroundTriangle2.RotationSpeed)
	end

	if BackgroundTriangle2.RotationDegrees > 360 then
		BackgroundTriangle2.RotationDegrees = 0
	end

	if BackgroundTriangle2.RotationDegrees < -360 then
		BackgroundTriangle2.RotationDegrees = 0
	end

--Make Triangle 2 rotation direction follow X direction, for more /slightly/ more accurate physics
	if BackgroundTriangle2.XDirection == 1 then
		BackgroundTriangle2.RotationDirection = 1
	end

	if BackgroundTriangle2.XDirection == 2 then
		BackgroundTriangle2.RotationDirection = 2
	end


--Triangle 3 Moving Background Symbol Logic

--Triangle 3 Movement Speed
	if BackgroundTriangle3.SpeedOption == 1 then
		BackgroundTriangle3.Speed = 0.7
	
	elseif BackgroundTriangle3.SpeedOption == 2 then
		BackgroundTriangle3.Speed = 1

	elseif BackgroundTriangle3.SpeedOption == 3 then
		BackgroundTriangle3.Speed = 1.2
	end


--Triangle 3: X Movement
	if BackgroundTriangle3.XDirection == 1 then
		BackgroundTriangle3.X = (BackgroundTriangle3.X - BackgroundTriangle3.Speed)

	elseif BackgroundTriangle3.XDirection == 2 then
		BackgroundTriangle3.X = (BackgroundTriangle3.X + BackgroundTriangle3.Speed)
	end

-- Triangle 3: X Direction Swap
	if BackgroundTriangle3.X <= (ScreenBoundary.XMin + (BackgroundTriangle3.ImageWidth /2)) then
		BackgroundTriangle3.XDirection = 2

	elseif BackgroundTriangle3.X >= (ScreenBoundary.XMax - (BackgroundTriangle3.ImageWidth /2)) then
		BackgroundTriangle3.XDirection = 1
	end

--Triangle 3: Y Movement
	if BackgroundTriangle3.YDirection == 1 then
		BackgroundTriangle3.Y = (BackgroundTriangle3.Y - BackgroundTriangle3.Speed)

	elseif BackgroundTriangle3.YDirection == 2 then
		BackgroundTriangle3.Y = (BackgroundTriangle3.Y + BackgroundTriangle3.Speed)
	end

--Triangle 3: Y Direction Swap
	if BackgroundTriangle3.Y <= (ScreenBoundary.YMin + (BackgroundTriangle3.ImageHeight /2)) then
		BackgroundTriangle3.YDirection = 2

	elseif BackgroundTriangle3.Y >= (ScreenBoundary.YMax - (BackgroundTriangle3.ImageHeight /2)) then
		BackgroundTriangle3.YDirection = 1
	end

--Triangle 3 Rotation

	if BackgroundTriangle3.RotationDirection == 1 then
		BackgroundTriangle3.RotationDegrees = (BackgroundTriangle3.RotationDegrees - BackgroundTriangle3.RotationSpeed)
		
	elseif BackgroundTriangle3.RotationDirection == 2 then
		BackgroundTriangle3.RotationDegrees = (BackgroundTriangle3.RotationDegrees + BackgroundTriangle3.RotationSpeed)
	end

	if BackgroundTriangle3.RotationDegrees > 360 then
		BackgroundTriangle3.RotationDegrees = 0
	end

	if BackgroundTriangle3.RotationDegrees < -360 then
		BackgroundTriangle3.RotationDegrees = 0
	end

--Make Triangle 3 rotation direction follow X direction, for more /slightly/ more accurate physics
	if BackgroundTriangle3.XDirection == 1 then
		BackgroundTriangle3.RotationDirection = 1
	end

	if BackgroundTriangle3.XDirection == 2 then
		BackgroundTriangle3.RotationDirection = 2
	end


--Cross 1 Moving Background Symbol Logic

--Cross 1 Movement Speed
	if BackgroundCross.SpeedOption == 1 then
		BackgroundCross.Speed = 0.7
	
	elseif BackgroundCross.SpeedOption == 2 then
		BackgroundCross.Speed = 1

	elseif BackgroundCross.SpeedOption == 3 then
		BackgroundCross.Speed = 1.2
	end


--Cross 1: X Movement
	if BackgroundCross.XDirection == 1 then
		BackgroundCross.X = (BackgroundCross.X - BackgroundCross.Speed)

	elseif BackgroundCross.XDirection == 2 then
		BackgroundCross.X = (BackgroundCross.X + BackgroundCross.Speed)
	end

-- Cross 1: X Direction Swap
	if BackgroundCross.X <= (ScreenBoundary.XMin + (BackgroundCross.ImageWidth /2)) then
		BackgroundCross.XDirection = 2

	elseif BackgroundCross.X >= (ScreenBoundary.XMax - (BackgroundCross.ImageWidth /2)) then
		BackgroundCross.XDirection = 1
	end

--Cross 1: Y Movement
	if BackgroundCross.YDirection == 1 then
		BackgroundCross.Y = (BackgroundCross.Y - BackgroundCross.Speed)

	elseif BackgroundCross.YDirection == 2 then
		BackgroundCross.Y = (BackgroundCross.Y + BackgroundCross.Speed)
	end

--Cross 1: Y Direction Swap
	if BackgroundCross.Y <= (ScreenBoundary.YMin + (BackgroundCross.ImageHeight /2)) then
		BackgroundCross.YDirection = 2

	elseif BackgroundCross.Y >= (ScreenBoundary.YMax - (BackgroundCross.ImageHeight /2)) then
		BackgroundCross.YDirection = 1
	end

--Cross 1 Rotation

	if BackgroundCross.RotationDirection == 1 then
		BackgroundCross.RotationDegrees = (BackgroundCross.RotationDegrees - BackgroundCross.RotationSpeed)
		
	elseif BackgroundCross.RotationDirection == 2 then
		BackgroundCross.RotationDegrees = (BackgroundCross.RotationDegrees + BackgroundCross.RotationSpeed)
	end

	if BackgroundCross.RotationDegrees > 360 then
		BackgroundCross.RotationDegrees = 0
	end

	if BackgroundCross.RotationDegrees < -360 then
		BackgroundCross.RotationDegrees = 0
	end

--Make Cross 1 rotation direction follow X direction, for more /slightly/ more accurate physics
	if BackgroundCross.XDirection == 1 then
		BackgroundCross.RotationDirection = 1
	end

	if BackgroundCross.XDirection == 2 then
		BackgroundCross.RotationDirection = 2
	end


--Cross 2 Moving Background Symbol Logic

--Cross 2 Movement Speed
	if BackgroundCross2.SpeedOption == 1 then
		BackgroundCross2.Speed = 0.7
	
	elseif BackgroundCross2.SpeedOption == 2 then
		BackgroundCross2.Speed = 1

	elseif BackgroundCross2.SpeedOption == 3 then
		BackgroundCross2.Speed = 1.2
	end


--Cross 2: X Movement
	if BackgroundCross2.XDirection == 1 then
		BackgroundCross2.X = (BackgroundCross2.X - BackgroundCross2.Speed)

	elseif BackgroundCross2.XDirection == 2 then
		BackgroundCross2.X = (BackgroundCross2.X + BackgroundCross2.Speed)
	end

-- Cross 2: X Direction Swap
	if BackgroundCross2.X <= (ScreenBoundary.XMin + (BackgroundCross2.ImageWidth /2)) then
		BackgroundCross2.XDirection = 2

	elseif BackgroundCross2.X >= (ScreenBoundary.XMax - (BackgroundCross2.ImageWidth /2)) then
		BackgroundCross2.XDirection = 1
	end

--Cross 2: Y Movement
	if BackgroundCross2.YDirection == 1 then
		BackgroundCross2.Y = (BackgroundCross2.Y - BackgroundCross2.Speed)

	elseif BackgroundCross2.YDirection == 2 then
		BackgroundCross2.Y = (BackgroundCross2.Y + BackgroundCross2.Speed)
	end

--Cross 2: Y Direction Swap
	if BackgroundCross2.Y <= (ScreenBoundary.YMin + (BackgroundCross2.ImageHeight /2)) then
		BackgroundCross2.YDirection = 2

	elseif BackgroundCross2.Y >= (ScreenBoundary.YMax - (BackgroundCross2.ImageHeight /2)) then
		BackgroundCross2.YDirection = 1
	end

--Cross 2 Rotation

	if BackgroundCross2.RotationDirection == 1 then
		BackgroundCross2.RotationDegrees = (BackgroundCross2.RotationDegrees - BackgroundCross2.RotationSpeed)
		
	elseif BackgroundCross2.RotationDirection == 2 then
		BackgroundCross2.RotationDegrees = (BackgroundCross2.RotationDegrees + BackgroundCross2.RotationSpeed)
	end

	if BackgroundCross2.RotationDegrees > 360 then
		BackgroundCross2.RotationDegrees = 0
	end

	if BackgroundCross2.RotationDegrees < -360 then
		BackgroundCross2.RotationDegrees = 0
	end

--Make Cross 2 rotation direction follow X direction, for more /slightly/ more accurate physics
	if BackgroundCross2.XDirection == 1 then
		BackgroundCross2.RotationDirection = 1
	end

	if BackgroundCross2.XDirection == 2 then
		BackgroundCross2.RotationDirection = 2
	end


--Cross 3 Moving Background Symbol Logic

--Cross 3 Movement Speed
	if BackgroundCross3.SpeedOption == 1 then
		BackgroundCross3.Speed = 0.7
	
	elseif BackgroundCross3.SpeedOption == 2 then
		BackgroundCross3.Speed = 1

	elseif BackgroundCross3.SpeedOption == 3 then
		BackgroundCross3.Speed = 1.2
	end


--Cross 3: X Movement
	if BackgroundCross3.XDirection == 1 then
		BackgroundCross3.X = (BackgroundCross3.X - BackgroundCross3.Speed)

	elseif BackgroundCross3.XDirection == 2 then
		BackgroundCross3.X = (BackgroundCross3.X + BackgroundCross3.Speed)
	end

-- Cross 3: X Direction Swap
	if BackgroundCross3.X <= (ScreenBoundary.XMin + (BackgroundCross3.ImageWidth /2)) then
		BackgroundCross3.XDirection = 2

	elseif BackgroundCross3.X >= (ScreenBoundary.XMax - (BackgroundCross3.ImageWidth /2)) then
		BackgroundCross3.XDirection = 1
	end

--Cross 3: Y Movement
	if BackgroundCross3.YDirection == 1 then
		BackgroundCross3.Y = (BackgroundCross3.Y - BackgroundCross3.Speed)

	elseif BackgroundCross3.YDirection == 2 then
		BackgroundCross3.Y = (BackgroundCross3.Y + BackgroundCross3.Speed)
	end

--Cross 3: Y Direction Swap
	if BackgroundCross3.Y <= (ScreenBoundary.YMin + (BackgroundCross3.ImageHeight /2)) then
		BackgroundCross3.YDirection = 2

	elseif BackgroundCross3.Y >= (ScreenBoundary.YMax - (BackgroundCross3.ImageHeight /2)) then
		BackgroundCross3.YDirection = 1
	end

--Cross 3 Rotation

	if BackgroundCross3.RotationDirection == 1 then
		BackgroundCross3.RotationDegrees = (BackgroundCross3.RotationDegrees - BackgroundCross3.RotationSpeed)
		
	elseif BackgroundCross3.RotationDirection == 2 then
		BackgroundCross3.RotationDegrees = (BackgroundCross3.RotationDegrees + BackgroundCross3.RotationSpeed)
	end

	if BackgroundCross3.RotationDegrees > 360 then
		BackgroundCross3.RotationDegrees = 0
	end

	if BackgroundCross3.RotationDegrees < -360 then
		BackgroundCross3.RotationDegrees = 0
	end

--Make Cross 3 rotation direction follow X direction, for more /slightly/ more accurate physics
	if BackgroundCross3.XDirection == 1 then
		BackgroundCross3.RotationDirection = 1
	end

	if BackgroundCross3.XDirection == 2 then
		BackgroundCross3.RotationDirection = 2
	end


--Button Tester Controls

--Triggers
	if buttons.held.l then
		image.blit(LeftTriggerImage, 67, 60)
		Checklist.LeftTrigger = 1
	end

	if buttons.held.r then
		image.blit(RightTriggerImage, 374, 60)
		Checklist.RightTrigger = 1
	end


--Dpad
	if buttons.held.left then
		image.blit(DpadLeftImage, 58, 127)
		Checklist.Left = 1
	end

	if buttons.held.right then
		image.blit(DpadRightImage, 86, 127)
		Checklist.Right = 1
	end

	if buttons.held.up then
		image.blit(DpadUpImage, 74, 111)
		Checklist.Up = 1
	end

	if buttons.held.down then
		image.blit(DpadDownImage, 74, 139)
		Checklist.Down = 1
	end


--Symbol Buttons
	if buttons.held.square then
		image.blit(SquareButtonImage, 378, 127)
		Checklist.Square = 1
	end

	if buttons.held.circle then
		image.blit(CircleImage, 410, 127)
		Checklist.Circle = 1
	end

	if buttons.held.triangle then
		image.blit(TriangleImage, 394, 111)
		Checklist.Triangle = 1
	end

	if buttons.held.cross then
		image.blit(CrossImage, 394, 143)
		Checklist.Cross = 1
	end


--Start/Select
	if buttons.held.select then
		image.blit(SelectButtonImage, 318, 207)
		Checklist.Select = 1
	end

	if buttons.held.start then
		image.blit(SelectButtonImage, 338, 207)
		Checklist.Start = 1
	end


--Volume Buttons
	if buttons.held.voldown then
		image.blit(VolumeDownButtonImage, 154, 207)
		Checklist.VolDown = 1
	end

	if buttons.held.volup then
		image.blit(VolumeUpButtonImage, 178, 207)
		Checklist.VolUp = 1
	end


--Screen Button
	if buttons.held.screen then
		image.blit(ScreenButtonImage, 282, 207)
		Checklist.Screen = 1
	end


--Note Button

	if buttons.held.note then
		image.blit(NoteButtonImage, 298, 207)
		Checklist.Note = 1
	end

	if hw.mute() == 1 or hw.volume() == 0 then
		image.blit(MuteIconImage, 415, 30)
	end


--WLAN Icon

--WLAN Icon Animation
function WLANIconAnimation()

image.blit(WLANIconPart1Image, 38, 176)

WLANIconAnimation_Counter = WLANIconAnimation_Counter + 1

	if WLANIconAnimation_Counter > 30 and WLANIconAnimation_Counter <= 90 then 
		image.blit(WLANIconPart2Image, 24, 171)
	end

	if WLANIconAnimation_Counter > 60 and WLANIconAnimation_Counter <= 90 then
		image.blit(WLANIconPart3Image, 12, 164)
	end

	if WLANIconAnimation_Counter >= 90 then
		WLANIconAnimation_Counter = 0
	end


--End Function
end


	if buttons.wlan or buttons.held.cross and buttons.held.l then
		Checklist.WLAN = 1
		WLANIconAnimation()
	else WLANIconAnimation_Counter = 0 --Resets WLAN icon animation when WLAN switch is turned off.
	end


--Hold Icon
	if buttons.held.hold then
		image.blit(HoldIconImage, 434, 160)
		Checklist.Hold = 1
	end


--Thumbstick Image & Tester Cursor Image

--Display Thumbstick Image
		image.blit(Thumbstick.Image, Thumbstick.X, Thumbstick.Y)	

	if buttons.analogx < -3 or buttons.analogx > 2 then -- +/- 3 integer dead zone (Left: -3,-2, -1; Right: 0, 1, 2)
		Cursor.X = math.ceil((buttons.analogx / 4) + 150) --Divided by 4 to shorten the distance the cursor image travels.
		Thumbstick.X = math.ceil((buttons.analogx / 22) + 71) --71 is the X position of the image being displayed.
		Thumbstick.Image = ThumbstickHighlightedImage
--		image.blit(ThumbstickImage, Thumbstick.X, Thumbstick.Y) --This image will not be displayed until the thumbstick is moved outside of the dead zone.
	else Cursor.X = 150 -- Keeps Cursor image X axis snapped within dead zone
		Thumbstick.X = 71 -- Keeps Thumbstick image X axis snapped within dead zone
		Thumbstick.Image = ThumbstickImage
	end

 	if buttons.analogy < -3 or buttons.analogy > 2 then
		Cursor.Y = math.ceil((buttons.analogy / 4) + 123)
		Thumbstick.Y = math.ceil((buttons.analogy / 22) + 167)
		Thumbstick.Image = ThumbstickHighlightedImage
--		image.blit(ThumbstickImage, Thumbstick.X, Thumbstick.Y)	
	else Cursor.Y = 123
		Thumbstick.Y = 167
	end


--Display Thumbstick Centering Text
	if buttons.analogx >= -3 and buttons.analogx <=2 then -- +/- 3 integer dead zone/centre
		screen.print(146, 180, "X Centered!", 0.5, Green)
	end

	if buttons.analogy >= -3 and buttons.analogy <=2 then -- +/- 3 integer dead zone/centre
		screen.print(146, 190, "Y Centered!", 0.5, Green)
	end

--Display Thumbstick Maximum Reached Text

	if buttons.analogx == -128 or buttons.analogx == 127 then
		screen.print(157, 180, "Maximum!", 0.5, Red)
	end

	if buttons.analogy == -128 or buttons.analogy == 127 then
		screen.print(157, 190, "Maximum!", 0.5, Red)
	end


--Button Sounds

--Triggers
	if buttons.l or buttons.r then
		sound.play(TriggerPressedSound, 5)

	elseif buttons.released.l or buttons.released.r then
		sound.play(TriggerReleasedSound, 6)
	end


--Dpad
	if buttons.left or buttons.right or buttons.up or buttons.down then
		sound.play(DpadPressedSound, 1)

	elseif buttons.released.left or buttons.released.right or buttons.released.up or buttons.released.down then
		sound.play(DpadReleasedSound, 2)
	end


--Symbol Buttons
	if buttons.square or buttons.circle or buttons.triangle or buttons.cross then
		sound.play(SymbolsPressedSound, 3)

	elseif buttons.released.square or buttons.released.circle or buttons.released.triangle or buttons.released.cross then
		sound.play(SymbolsReleasedSound, 4)
	end


--Select/Start Buttons
	if buttons.select or buttons.start then
		sound.play(SelectStartPressedSound, 7)

	elseif buttons.released.select or buttons.released.start then
		sound.play(SelectStartReleasedSound, 8)
	end


--Volume/Screen/Note Buttons
	if buttons.voldown or buttons.volup or buttons.screen or buttons.note then
		sound.play(DpadPressedSound, 1)

	elseif buttons.released.voldown or buttons.released.volup or buttons.released.screen or buttons.released.note then
		sound.play(DpadReleasedSound, 2)
	end


--Checklist Ticks

	if Checklist.LeftTrigger == 1 then
		image.blit(TickIconImage, 273, 104)
	end

	if Checklist.RightTrigger == 1 then
		image.blit(TickIconImage, 351, 104)
	end

	if Checklist.Left == 1 then
		image.blit(TickIconImage, 251, 115)
	end

	if Checklist.Right == 1 then
		image.blit(TickIconImage, 257, 125)
	end

	if Checklist.Up == 1 then
		image.blit(TickIconImage, 246, 136)
	end

	if Checklist.Down == 1 then
		image.blit(TickIconImage, 259, 147)
	end

	if Checklist.Square == 1 then
		image.blit(TickIconImage, 343, 115)
	end

	if Checklist.Circle == 1 then
		image.blit(TickIconImage, 336, 125)
	end

	if Checklist.Triangle == 1 then
		image.blit(TickIconImage, 346, 136)
	end

	if Checklist.Cross == 1 then
		image.blit(TickIconImage, 336, 147)
	end

	if Checklist.Select == 1 then
		image.blit(TickIconImage, 261, 158)
	end

	if Checklist.Start == 1 then
		image.blit(TickIconImage, 333, 158)
	end

	if Checklist.VolDown == 1 then
		image.blit(TickIconImage, 276, 169)
	end

	if Checklist.VolUp == 1 then
		image.blit(TickIconImage, 263, 179)
	end

	if Checklist.Screen == 1 then
		image.blit(TickIconImage, 342, 169)
	end

	if Checklist.Note == 1 then
		image.blit(TickIconImage, 332, 179)
	end

	if Checklist.WLAN == 1 then
		image.blit(TickIconImage, 257, 190)
	end

	if Checklist.Hold == 1 then
		image.blit(TickIconImage, 331, 190)
	end


--Reset Logic
	if buttons.held.select and buttons.held.start then
		Reset.Counter = Reset.Counter + 1
	else Reset.Counter = 0
	end


	if Reset.Counter == 0 then
		screen.print(128, 249, "Hold Select and Start to Reset")
	elseif Reset.Counter > 0 and Reset.Counter <= 60 then
		screen.print(190, 249, "Resetting in 3 .", 0.7, Red)
	elseif Reset.Counter > 60 and Reset.Counter <= 120 then
		screen.print(190, 249, "Resetting in 2 . .", 0.7, Red)
	elseif Reset.Counter > 120 and Reset.Counter <= 180 then
		screen.print(190, 249, "Resetting in 1. . .", 0.7, Red)
	elseif Reset.Counter >= 180 then
--Unload Sounds
	DpadPressedSound = nil
	DpadReleasedSound = nil
	SymbolsPressedSound = nil
	SymbolsReleasedSound = nil
	TriggerPressedSound = nil
	TriggerReleasedSound = nil
	SelectStartPressedSound = nil
	SelectStartReleasedSound = nil
--Reload Script
	dofile("Script.lua")

--[[
		Checklist.LeftTrigger = 0
		Checklist.RightTrigger = 0
		Checklist.Square = 0
		Checklist.Circle = 0
		Checklist.Triangle = 0
		Checklist.Cross = 0
		Checklist.Left = 0
		Checklist.Right = 0
		Checklist.Up = 0
		Checklist.Down = 0
		Checklist.Select = 0
		Checklist.Start = 0
		Checklist.VolDown = 0
		Checklist.VolUp = 0
		Checklist.Screen = 0
		Checklist.Note = 0
		Checklist.WLAN = 0
		Checklist.Hold = 0
--]]		
	end


--DEBUG

function DebugMenu()

screen.print(150, 10, "DEBUG MODE", 1.0, Green)

--Reset
	if buttons.start then
		dofile("Crashed it lol (") -- Putting the extra open bracket here makes a smiley face when I force the code to crash (: (it's trying to load a non-existent file)
	end


--FPS
screen.print(400, 10, "FPS: " ..screen.fps())


--Screenshot
--if buttons.held.start and buttons.held.l and buttons.held.R then
--	screen.shot()
--end


--Moving Background Symbols Debug Code
--Square 1
if buttons.held.square then
	screen.print(BackgroundSquare.X, BackgroundSquare.Y, "Square 1")
	screen.print(BackgroundSquare.X, BackgroundSquare.Y + 20, "X:" ..BackgroundSquare.X)
	screen.print(BackgroundSquare.X, BackgroundSquare.Y + 40, "Y:" ..BackgroundSquare.Y)
	screen.print(BackgroundSquare.X, BackgroundSquare.Y + 60, "Speed:" ..BackgroundSquare.Speed)
	screen.print(BackgroundSquare.X, BackgroundSquare.Y + 80, "Rotation Spd:" ..BackgroundSquare.RotationSpeed)
	screen.print(BackgroundSquare.X, BackgroundSquare.Y + 100, "Scale:" ..BackgroundSquare.Scale)

--Square 2
	screen.print(BackgroundSquare2.X, BackgroundSquare2.Y, "Square 2")
	screen.print(BackgroundSquare2.X, BackgroundSquare2.Y + 20, "X:" ..BackgroundSquare2.X)
	screen.print(BackgroundSquare2.X, BackgroundSquare2.Y + 40, "Y:" ..BackgroundSquare2.Y)
	screen.print(BackgroundSquare2.X, BackgroundSquare2.Y + 60, "Speed:" ..BackgroundSquare2.Speed)
	screen.print(BackgroundSquare2.X, BackgroundSquare2.Y + 80, "Rotation Spd:" ..BackgroundSquare2.RotationSpeed)
	screen.print(BackgroundSquare2.X, BackgroundSquare2.Y + 100, "Scale:" ..BackgroundSquare2.Scale)

--Square 3
	screen.print(BackgroundSquare3.X, BackgroundSquare3.Y, "Square 3")
	screen.print(BackgroundSquare3.X, BackgroundSquare3.Y + 20, "X:" ..BackgroundSquare3.X)
	screen.print(BackgroundSquare3.X, BackgroundSquare3.Y + 40, "Y:" ..BackgroundSquare3.Y)
	screen.print(BackgroundSquare3.X, BackgroundSquare3.Y + 60, "Speed:" ..BackgroundSquare3.Speed)
	screen.print(BackgroundSquare3.X, BackgroundSquare3.Y + 80, "Rotation Spd:" ..BackgroundSquare3.RotationSpeed)
	screen.print(BackgroundSquare3.X, BackgroundSquare3.Y + 100, "Scale:" ..BackgroundSquare3.Scale)
end


--Circle 1
if buttons.held.circle then
	screen.print(BackgroundCircle.X, BackgroundCircle.Y, "Circle 1")
	screen.print(BackgroundCircle.X, BackgroundCircle.Y + 20, "X:" ..BackgroundCircle.X)
	screen.print(BackgroundCircle.X, BackgroundCircle.Y + 40, "Y:" ..BackgroundCircle.Y)
	screen.print(BackgroundCircle.X, BackgroundCircle.Y + 60, "Speed:" ..BackgroundCircle.Speed)
	screen.print(BackgroundCircle.X, BackgroundCircle.Y + 80, "Rotation Spd:" ..BackgroundCircle.RotationSpeed)
	screen.print(BackgroundCircle.X, BackgroundCircle.Y + 100, "Scale:" ..BackgroundCircle.Scale)

--Circle 2
	screen.print(BackgroundCircle2.X, BackgroundCircle2.Y, "Circle 2")
	screen.print(BackgroundCircle2.X, BackgroundCircle2.Y + 20, "X:" ..BackgroundCircle2.X)
	screen.print(BackgroundCircle2.X, BackgroundCircle2.Y + 40, "Y:" ..BackgroundCircle2.Y)
	screen.print(BackgroundCircle2.X, BackgroundCircle2.Y + 60, "Speed:" ..BackgroundCircle2.Speed)
	screen.print(BackgroundCircle2.X, BackgroundCircle2.Y + 80, "Rotation Spd:" ..BackgroundCircle2.RotationSpeed)
	screen.print(BackgroundCircle2.X, BackgroundCircle2.Y + 100, "Scale:" ..BackgroundCircle2.Scale)

--Circle 3
	screen.print(BackgroundCircle3.X, BackgroundCircle3.Y, "Circle 3")
	screen.print(BackgroundCircle3.X, BackgroundCircle3.Y + 20, "X:" ..BackgroundCircle3.X)
	screen.print(BackgroundCircle3.X, BackgroundCircle3.Y + 40, "Y:" ..BackgroundCircle3.Y)
	screen.print(BackgroundCircle3.X, BackgroundCircle3.Y + 60, "Speed:" ..BackgroundCircle3.Speed)
	screen.print(BackgroundCircle3.X, BackgroundCircle3.Y + 80, "Rotation Spd:" ..BackgroundCircle3.RotationSpeed)
	screen.print(BackgroundCircle3.X, BackgroundCircle3.Y + 100, "Scale:" ..BackgroundCircle3.Scale)
end


--Triangle 1
if buttons.held.triangle then
	screen.print(BackgroundTriangle.X, BackgroundTriangle.Y, "Triangle 1")
	screen.print(BackgroundTriangle.X, BackgroundTriangle.Y + 20, "X:" ..BackgroundTriangle.X)
	screen.print(BackgroundTriangle.X, BackgroundTriangle.Y + 40, "Y:" ..BackgroundTriangle.Y)
	screen.print(BackgroundTriangle.X, BackgroundTriangle.Y + 60, "Speed:" ..BackgroundTriangle.Speed)
	screen.print(BackgroundTriangle.X, BackgroundTriangle.Y + 80, "Rotation Spd:" ..BackgroundTriangle.RotationSpeed)
	screen.print(BackgroundTriangle.X, BackgroundTriangle.Y + 100, "Scale:" ..BackgroundTriangle.Scale)

--Triangle 2
	screen.print(BackgroundTriangle2.X, BackgroundTriangle2.Y, "Triangle 2")
	screen.print(BackgroundTriangle2.X, BackgroundTriangle2.Y + 20, "X:" ..BackgroundTriangle2.X)
	screen.print(BackgroundTriangle2.X, BackgroundTriangle2.Y + 40, "Y:" ..BackgroundTriangle2.Y)
	screen.print(BackgroundTriangle2.X, BackgroundTriangle2.Y + 60, "Speed:" ..BackgroundTriangle2.Speed)
	screen.print(BackgroundTriangle2.X, BackgroundTriangle2.Y + 80, "Rotation Spd:" ..BackgroundTriangle2.RotationSpeed)
	screen.print(BackgroundTriangle2.X, BackgroundTriangle2.Y + 100, "Scale:" ..BackgroundTriangle2.Scale)

--Triangle 3
	screen.print(BackgroundTriangle3.X, BackgroundTriangle3.Y, "Triangle 3")
	screen.print(BackgroundTriangle3.X, BackgroundTriangle3.Y + 20, "X:" ..BackgroundTriangle3.X)
	screen.print(BackgroundTriangle3.X, BackgroundTriangle3.Y + 40, "Y:" ..BackgroundTriangle3.Y)
	screen.print(BackgroundTriangle3.X, BackgroundTriangle3.Y + 60, "Speed:" ..BackgroundTriangle3.Speed)
	screen.print(BackgroundTriangle3.X, BackgroundTriangle3.Y + 80, "Rotation Spd:" ..BackgroundTriangle3.RotationSpeed)
	screen.print(BackgroundTriangle3.X, BackgroundTriangle3.Y + 100, "Scale:" ..BackgroundTriangle3.Scale)
end

--Cross 1
if buttons.held.cross then
	screen.print(BackgroundCross.X, BackgroundCross.Y, "Cross 1")
	screen.print(BackgroundCross.X, BackgroundCross.Y + 20, "X:" ..BackgroundCross.X)
	screen.print(BackgroundCross.X, BackgroundCross.Y + 40, "Y:" ..BackgroundCross.Y)
	screen.print(BackgroundCross.X, BackgroundCross.Y + 60, "Speed:" ..BackgroundCross.Speed)
	screen.print(BackgroundCross.X, BackgroundCross.Y + 80, "Rotation Spd:" ..BackgroundCross.RotationSpeed)
	screen.print(BackgroundCross.X, BackgroundCross.Y + 100, "Scale:" ..BackgroundCross.Scale)

--Cross 2
	screen.print(BackgroundCross2.X, BackgroundCross2.Y, "Cross 2")
	screen.print(BackgroundCross2.X, BackgroundCross2.Y + 20, "X:" ..BackgroundCross2.X)
	screen.print(BackgroundCross2.X, BackgroundCross2.Y + 40, "Y:" ..BackgroundCross2.Y)
	screen.print(BackgroundCross2.X, BackgroundCross2.Y + 60, "Speed:" ..BackgroundCross2.Speed)
	screen.print(BackgroundCross2.X, BackgroundCross2.Y + 80, "Rotation Spd:" ..BackgroundCross2.RotationSpeed)
	screen.print(BackgroundCross2.X, BackgroundCross2.Y + 100, "Scale:" ..BackgroundCross2.Scale)

--Cross 3
	screen.print(BackgroundCross3.X, BackgroundCross3.Y, "Cross 3")
	screen.print(BackgroundCross3.X, BackgroundCross3.Y + 20, "X:" ..BackgroundCross3.X)
	screen.print(BackgroundCross3.X, BackgroundCross3.Y + 40, "Y:" ..BackgroundCross3.Y)
	screen.print(BackgroundCross3.X, BackgroundCross3.Y + 60, "Speed:" ..BackgroundCross3.Speed)
	screen.print(BackgroundCross3.X, BackgroundCross3.Y + 80, "Rotation Spd:" ..BackgroundCross3.RotationSpeed)
	screen.print(BackgroundCross3.X, BackgroundCross3.Y + 100, "Scale:" ..BackgroundCross3.Scale)

end

--End DebugMenu function
end


--Activate Debug Menu
	if buttons.held.l and buttons.held.r then
		DebugMenu()
	end


screen.flip()
end