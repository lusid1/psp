function onDebug(msg)
    local sx, spd, wt, lt = 0, 1, 15, os.clock()
    local ln = {}
    for l in tostring(msg):gmatch("([^\n]*)\n?") do table.insert(ln, " " .. l .. " ") end
    local mw = 0
    for i = 1, #ln do
        local w = #ln[i]
        if w > mw then mw = w end
    end
    local ram = string.format("%.2f", os.ram() / 1048576)
    local tot = string.format("%.2f", os.totalram() / 1048576)
    local mob = hw.gen()
    local mdl = hw.getmodel()
    local cpu = os.cpu()
    while true do
        buttons.read()
        draw.fillrect(0, 0, 480, 272, color.new(80, 0, 0))
        screen.txtcolor(color.new(255, 255, 255))
        screen.consolexy(1, 1)
        screen.consoleprint("Ooops, something bad happened!")
        screen.consolexy(1, 2)
        screen.consoleprint("report bugs to @koutsie on discord")
        screen.consolexy(1, 3)
        screen.consoleprint("or on irc #sauna @ libera.chat")
        screen.consolexy(1, 4)
        screen.consoleprint("https://the-sauna.icu/")
        screen.consolexy(1, 6)
        screen.consoleprint("ram:" .. ram .. " MiB / total: " .. tot .. " MiB/ mobo:")
        screen.consolexy(1, 7)
        screen.consoleprint(mob .. " / " .. mdl)
        screen.consolexy(1, 8)
        screen.consoleprint("cpu: " .. cpu .. " MHz")
        screen.txtcolor(color.new(255, 255, 0))
        for i = 1, #ln do
            local t = " " .. ln[i] .. " "
            local s = math.floor(sx) + 1
            screen.consolexy(1, 10 + i)
            screen.consoleprint(t:sub(s))
        end
        screen.txtcolor(color.new(255, 255, 255))
        screen.consolexy(1, 32)
        screen.consoleprint("LEFT/RIGHT scroll | START exit")
        screen.flip()
        os.delay(16)
        if buttons.held.left then
            sx = math.max(0, sx - 1); lt = os.clock()
        elseif buttons.held.right then
            sx = math.min(mw + 40, sx + 1); lt = os.clock()
        elseif os.clock() - lt > wt then
            sx = sx + spd
        end
        if sx > mw + 40 then sx = 0 end
        if buttons.start then break end
    end
end

function inito()
    screen.txtcolor(color.new(120, 120, 30))
    screen.consolexy(1, 1)
    screen.consoleprint(string.reverse("eistuoK yb revaeMneercS"))
    screen.consolexy(1, 2)
    screen.consoleprint(string.reverse("/revaeMneercS/uci.anuas-eht//:sptth"))
    screen.consolexy(1, 15)
    screen.txtcolor(color.new(120, 30, 30))
    screen.consoleprint(string.reverse("!demmacs neeb evah uoy ,ti rof diap uoy fi ,ERAWTFOS EERF si sihT"))
    screen.consolexy(1, 32)
    screen.txtcolor(color.new(120, 25, 60))
    screen.consoleprint(string.reverse(")segami raC ,aedi tset gnitsohG( odnammoKlatoT ot stuotuohS"))
    screen.flip()
    os.delay(3333)
end
