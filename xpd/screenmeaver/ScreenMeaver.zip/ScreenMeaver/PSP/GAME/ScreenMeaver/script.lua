-- ScreenMeaver - The PSP Display testing suite
-- https://the-sauna.icu/BatterySteve/
-- THIS IS FREE SOFTWARE, IF YOU PAID FOR IT, YOU GOT SCAMMED!

require("modules")
local SCREEN_WIDTH, SCREEN_HEIGHT = 480, 272

inito()

os.cpu(333)
screen.brightness(100)

local colors = {
    black   = color.new(0, 0, 0),
    white   = color.new(255, 255, 255),
    yellow  = color.new(255, 255, 0),
    red     = color.new(255, 0, 0),
    green   = color.new(0, 255, 0),
    teal    = color.new(0, 255, 255),
    magenta = color.new(255, 0, 255)
}

local tests = {
    { name = "Colors",            animated = true },
    { name = "Gradients",         animated = false },
    { name = "Checkerboard",      animated = false },
    { name = "Grid",              animated = true },
    { name = "Bars",              animated = false },
    { name = "Contrast",          animated = false },
    { name = "Text",              animated = false },
    { name = "Bouncy",            animated = true },
    { name = "Ghosting (Simple)", animated = true },
    { name = "Ghosting (Car)",    animated = true },
    { name = "Ghosting (Line)",   animated = true },
    { name = "Image Scroll",      animated = true },
    { name = "Viewing Angles",    animated = true },
    { name = "Brightness",        animated = false },
    { name = "Response Time",     animated = true }
}

local currentTest = 1
local invertColor = false
local sweepVertical = false
local lastButtonPressTime = os.clock()
local carImage = image.loadv("car3.png")
local car_rgb = image.loadv("car_rgb.png")
local img = image.loadv("bg.png")
image.fxinvert(carImage)

local function printShadowed(x, y, text, scale, textColor)
    screen.print(x + 1, y + 1, text, scale, colors.black)
    screen.print(x, y, text, scale, textColor)
end

local function showUI()
    local elapsed = os.clock() - lastButtonPressTime
    if elapsed >= 15 then return end
    local test = tests[currentTest]
    local testCount = #tests
    printShadowed(5, 6, string.format("%s (%d/%d)", test.name, currentTest, testCount), 0.6, colors.white)
    printShadowed(5, SCREEN_HEIGHT - 20, "LEFT/RIGHT: Navigate | START: Exit", 0.5, colors.white)
end

local function handleInput()
    buttons.read()
    local released = buttons.released
    if not (released.right or released.left or released.start) then
        return true
    end
    lastButtonPressTime = os.clock()
    local testCount = #tests
    if released.right then
        currentTest = (currentTest % testCount) + 1
        return true
    elseif released.left then
        currentTest = ((currentTest - 2) % testCount) + 1
        return true
    elseif released.start then
        return false
    end
    return true
end

local function testColors()
    local t = 0
    local presetIndex = 0
    local presets = {
        colors.green,
        colors.yellow,
        colors.red,
        colors.teal,
        colors.black,
        colors.white,
        colors.magenta
    }
    local animated = true

    while currentTest == 1 do
        if not handleInput() then
            break
        end
        buttons.read()
        if buttons.released.down then
            animated = false
            presetIndex = (presetIndex % #presets) + 1
        elseif buttons.released.up then
            animated = true
        end

        if animated then
            t = os.clock() * 1.570796327
            local r = math.floor(127.5 + 127.5 * math.sin(t))
            local g = math.floor(127.5 + 127.5 * math.sin(t + 2.094395102))
            local b = math.floor(127.5 + 127.5 * math.sin(t + 4.188790205))
            screen.clear(color.new(r, g, b))
            printShadowed(5, 20, string.format("RGB: %d %d %d", r, g, b), 0.5, colors.white)
        else
            screen.clear(presets[presetIndex])
        end

        showUI()
        screen.flip()
        os.delay(2)
    end
end



local function testGradients()
    local colors = {}
    local invWidth = 360 / SCREEN_WIDTH
    for x = 0, SCREEN_WIDTH - 1 do
        local h = x * invWidth
        local q = 1 - math.abs((h / 60) % 2 - 1)
        local r, g, b
        if h < 60 then
            r, g, b = 1, q, 0
        elseif h < 120 then
            r, g, b = q, 1, 0
        elseif h < 180 then
            r, g, b = 0, 1, q
        elseif h < 240 then
            r, g, b = 0, q, 1
        elseif h < 300 then
            r, g, b = q, 0, 1
        else
            r, g, b = 1, 0, q
        end

        colors[x] = color.new(r * 255, g * 255, b * 255)
    end

    for x = 0, SCREEN_WIDTH - 1 do
        draw.fillrect(x, 0, 1, SCREEN_HEIGHT, colors[x])
    end
end

local function testCheckerboard()
    -- i know the checkerboard is not actually squares- shh!
    local size = 16
    local completeRows = math.floor(SCREEN_HEIGHT / size)
    local completeCols = math.floor(SCREEN_WIDTH / size)
    local remainderHeight = SCREEN_HEIGHT % size
    local remainderWidth = SCREEN_WIDTH % size
    for y = 0, completeRows do
        local evenY = y % 2 == 0
        local yPos = y * size
        local height = (y == completeRows) and remainderHeight or size
        if height > 0 then
            for x = 0, completeCols do
                if (x % 2 == 0) ~= evenY then
                    local width = (x == completeCols) and remainderWidth or size
                    if width > 0 then
                        draw.fillrect(x * size, yPos, width, height, colors.white)
                    end
                end
            end
        end
    end
end

local function testGrid()
    -- i know the grid is not actually squares- shh!
    local cols, rows = 16, 8
    local colWidth = math.floor(SCREEN_WIDTH / cols)
    local rowHeight = math.floor(SCREEN_HEIGHT / rows)
    local move = true
    local x, y = 0, 0

    while currentTest == 4 do
        if not handleInput() then
            return false
        end
        buttons.read()
        if buttons.down then move = false end
        if buttons.up then move = true end
        for r = 0, rows do
            local yPos = r * rowHeight
            if r == rows then yPos = SCREEN_HEIGHT - 1 end
            draw.line(0, yPos, SCREEN_WIDTH - 1, yPos, colors.white)
        end

        for c = 0, cols do
            local xPos = c * colWidth
            if c == cols then xPos = SCREEN_WIDTH - 1 end
            draw.line(xPos, 0, xPos, SCREEN_HEIGHT - 1, colors.white)
        end

        if move then
            x = x + 1
            if x > cols - 1 then
                x = 0
                y = y + 1
                if y > rows - 1 then
                    y = 0
                end
            end
        end

        local w = (x == cols - 1) and SCREEN_WIDTH - x * colWidth or colWidth
        local h = (y == rows - 1) and SCREEN_HEIGHT - y * rowHeight or rowHeight
        draw.fillrect(x * colWidth, y * rowHeight, w, h, colors.white)
        showUI()
        screen.flip()
    end
end


local function testBars()
    local cx, cy = SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2
    local bars = {
        color.new(255, 255, 255),
        color.new(255, 255, 0),
        color.new(0, 255, 255),
        color.new(0, 255, 0),
        color.new(255, 0, 255),
        color.new(255, 0, 0),
        color.new(0, 0, 255)
    }
    local barW = SCREEN_WIDTH / 7
    local barH = SCREEN_HEIGHT * 0.45
    local x = 0
    for i = 1, 7 do
        draw.fillrect(x, 0, barW, barH, bars[i])
        x = x + barW
    end

    local grayY = barH + 6
    draw.gradrect(0, grayY, SCREEN_WIDTH, 16, color.new(0, 0, 0), color.new(255, 255, 255), 1)

    local stepY = grayY + 22
    local stepW = SCREEN_WIDTH / 7
    x = 0
    for i = 0, 7 do
        local s = i * 36.43
        draw.fillrect(x, stepY, stepW, 22, color.new(s, s, s))
        x = x + stepW
    end

    local gradH = SCREEN_HEIGHT - stepY - 22
    local offset = (os.clock() * 0.05 * SCREEN_WIDTH) % SCREEN_WIDTH
    local black = color.new(0, 0, 0)
    local white = color.new(255, 255, 255)
    draw.gradrect(offset, stepY + 22, SCREEN_WIDTH - offset, gradH, black, white, 1)
    if offset > 0 then
        draw.gradrect(0, stepY + 22, offset, gradH, black, white, 1)
    end

    draw.line(cx, 0, cx, SCREEN_HEIGHT, white)
    draw.line(0, cy, SCREEN_WIDTH, cy, white)
end

local function testContrast()
    screen.txtcolor(color.new(255, 255, 255))
    local stps = 16
    local bwid = SCREEN_WIDTH / stps
    local sel = padpos or 0

    if buttons.down then
        sel = (sel + 1) % (stps + 1)
        padpos = sel
    elseif buttons.up then
        sel = (sel - 1) % (stps + 1)
        padpos = sel
    end

    if sel == 0 then
        for i = 0, stps - 1 do
            local nx = math.floor((i + 1) * bwid)
            local cx = math.floor(i * bwid)
            local wid = nx - cx
            local val = math.floor((i / (stps - 1)) * 255)
            draw.fillrect(cx, 0, wid, SCREEN_HEIGHT, color.new(val, val, val))
            local txt = tostring(val)
            local tw = screen.textwidth(txt) or 8
            local tx = cx + (wid - tw) / 2 + 12
            local ty = 15
            local col
            if val < 128 then
                col = color.new(255, 255, 255)
            else
                col = color.new(0, 0, 0)
            end
            screen.print(math.floor(tx), ty, txt, 0.25, col)
        end
    else
        local val = math.floor(((sel - 1) / (stps - 1)) * 255)
        draw.fillrect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, color.new(val, val, val))
        screen.consolexy(60, 28)
        screen.consoleprint(tostring(val))
    end
end

local function testText()
    local text =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ\n\n" ..
        "abcdefghijklmnopqrstuvwxyz\n\n" ..
        "1234567890!@#$%^&*()_+-=\n\n" ..
        "The quick brown fox jumps\n\n" ..
        "over the lazy dog\n\n" .. "\n\n\n" .. "ÄÖÅ!@ -|+´\n\n" .. "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ\n\n"

    printShadowed(10, 50, text, 0.5, colors.white)
    printShadowed(10, 140, "Coloured text!", 0.5, colors.yellow)
end

local function testBouncy()
    local x, y, dx, dy = 100, 100, 2, 1
    local maxX = SCREEN_WIDTH - 60
    local maxY = SCREEN_HEIGHT - 30
    while currentTest == 8 do
        if not handleInput() then
            return false
        end
        local t = os.clock()
        screen.clear(
            color.new(
                math.floor(127.5 + 127.5 * math.sin(t * 0.3)),
                math.floor(127.5 + 127.5 * math.sin(t * 0.4 + 2)),
                math.floor(127.5 + 127.5 * math.sin(t * 0.5 + 4))
            )
        )
        x = x + dx
        y = y + dy
        if x < 5 or x > maxX then
            dx = -dx
        end
        if y < 20 or y > maxY then
            dy = -dy
        end
        printShadowed(x, y, "PSP", 2.0, colors.white)
        showUI()
        screen.flip()
        os.delay(4)
    end
    return true
end

local function testGhosting()
    local cubeSize = 40
    local speed = 2
    local xPos = 0
    local direction = 1
    local yPos = 20
    local yDir = 1
    local yMin = 20
    local yMax = SCREEN_HEIGHT - cubeSize - 20
    local textX = SCREEN_WIDTH / 2 - 60
    local textY = 30
    local invertColors = false

    while currentTest == 9 do
        if not handleInput() then return false end

        if buttons.down then
            invertColors = true
        elseif buttons.up then
            invertColors = false
        end

        local bgColor = invertColors and colors.white or colors.black
        local fgColor = invertColors and colors.black or colors.white

        xPos = xPos + (speed * direction)
        if xPos <= 0 or xPos >= (SCREEN_WIDTH - cubeSize) then
            direction = -direction
        end

        yPos = yPos + (speed * yDir)
        if yPos <= yMin then
            yPos = yMin
            yDir = 1
        elseif yPos >= yMax then
            yPos = yMax
            yDir = -1
        end

        screen.clear(bgColor)
        draw.fillrect(xPos, (SCREEN_HEIGHT - cubeSize) / 2, cubeSize, cubeSize, fgColor)
        draw.fillrect((SCREEN_WIDTH - cubeSize) / 2, yPos, cubeSize, cubeSize, fgColor)
        showUI()
        screen.flip()
        os.delay(4)
    end
    return true
end

local function testGhostingCar()
    local car1X = 0
    local car2X = 0
    local car3X = 0
    local speed1 = 8
    local speed2 = 16
    local speed3 = 32
    local carWidth = 64
    local lane1Y = 30
    local lane2Y = 100
    local lane3Y = 170
    local useColorCar = padpos or 0
    local resetX = -carWidth

    while currentTest == 10 do
        if not handleInput() then
            return false
        end
        if buttons.down then
            useColorCar = 1
            local padpos = 1
        elseif buttons.up then
            useColorCar = 0
            local padpos = 0
        end

        local currentCar = (useColorCar == 1) and car_rgb or carImage

        car1X = car1X + speed1
        if car1X > SCREEN_WIDTH then
            car1X = resetX
        end
        car2X = car2X + speed2
        if car2X > SCREEN_WIDTH then
            car2X = resetX
        end
        car3X = car3X + speed3
        if car3X > SCREEN_WIDTH then
            car3X = resetX
        end

        image.blit(currentCar, car1X, lane1Y)
        image.blit(currentCar, car2X, lane2Y)
        image.blit(currentCar, car3X, lane3Y)
        showUI()
        screen.flip()
        os.delay(4)
    end
    return true
end

local function testGenericImageScroll()
    local scrollX = 0
    local speed = 0.1

    while currentTest == 12 do
        if not handleInput() then
            return false
        end
        buttons.read()
        if buttons.down then
            speed = 0.01
        elseif buttons.up then
            speed = 0.1
        end

        scrollX = (scrollX + 60 * speed) % image.getw(img)

        image.blit(img, -scrollX, 0)
        image.blit(img, image.getw(img) - scrollX, 0)

        showUI()
        screen.flip()
        os.delay(4)
    end
end

local function testGhostingLineSweep()
    local linePos = 0
    local speed = 20
    local white = color.new(255, 255, 255)
    local black = color.new(0, 0, 0)

    while currentTest == 11 do
        if not handleInput() then return false end

        if buttons.down then
            sweepVertical = not sweepVertical
            linePos = 0
        elseif buttons.up then
            invertColor = not invertColor
        elseif buttons.square then
            speed = 100
        elseif buttons.circle then
            speed = 20
        end

        local bgColor = invertColor and white or black
        local lineColor = invertColor and black or white

        draw.fillrect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, bgColor)

        if sweepVertical then
            draw.fillrect(0, linePos, SCREEN_WIDTH, 20, lineColor)
        else
            draw.fillrect(linePos, 0, 15, SCREEN_HEIGHT, lineColor)
        end

        linePos = linePos + speed
        if sweepVertical and linePos > SCREEN_HEIGHT or not sweepVertical and linePos > SCREEN_WIDTH then
            linePos = 0 + math.random(-30, 10)
        end

        showUI()
        screen.flip()
        os.delay(4)
    end
    return true
end

local function testAngles()
    local circles = {
        { x = SCREEN_WIDTH * 0.15, y = SCREEN_HEIGHT * 0.15 },
        { x = SCREEN_WIDTH * 0.85, y = SCREEN_HEIGHT * 0.15 },
        { x = SCREEN_WIDTH * 0.5,  y = SCREEN_HEIGHT * 0.5 },
        { x = SCREEN_WIDTH * 0.15, y = SCREEN_HEIGHT * 0.85 },
        { x = SCREEN_WIDTH * 0.85, y = SCREEN_HEIGHT * 0.85 }
    }
    local radius = math.min(SCREEN_WIDTH, SCREEN_HEIGHT) * 0.12
    local circleCount = #circles
    local white = color.new(255, 255, 255)
    local black = color.new(0, 0, 0)

    while currentTest == 13 do
        if not handleInput() then
            return false
        end
        draw.fillrect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, black)
        for i = 1, circleCount do
            draw.gradcircle(circles[i].x, circles[i].y, radius, white, black, 32)
        end
        showUI()
        screen.flip()
        os.delay(4)
    end
    return true
end

local function testBrightness()
    local ok, b = pcall(screen.brightness)
    --printShadowed(20, 60, string.format("Brightness: %s", tostring(b)), 0.8, colors.white)
    printShadowed(20, 100, "Brightness: Yes.", 0.5, colors.white)
end

local function responseTime()
    local boxSize = 64
    local boxX = (SCREEN_WIDTH - boxSize) / 2
    local boxY = (SCREEN_HEIGHT - boxSize) / 2
    printShadowed(20, 20, "Press CROSS to continue.", 1, color.new(15, 15, 15))
    screen.flip()
    while currentTest == 15 do
        power.tick()
        buttons.waitforkey(__CROSS)
        draw.fillrect(boxX, boxY, boxSize, boxSize, colors.white)
        screen.flip()
        os.delay(4000)
        currentTest = 1
        return true
    end
    return true
end

--buttons.interval(40, 10)
local running = true

-- having two tables for tests
-- is dumb but, we ball - i cant exactly do a
-- goto, should probably do this like i do it in
local tests = {
    testColors,
    testGradients,
    testCheckerboard,
    testGrid,
    testBars,
    testContrast,
    testText,
    testBouncy,
    testGhosting,
    testGhostingCar,
    testGhostingLineSweep,
    testGenericImageScroll,
    testAngles,
    testBrightness,
    responseTime
}

while running do
    if not handleInput() then
        break
    end
    power.tick()
    screen.clear(colors.black)
    local testFunc = tests[currentTest]
    if testFunc then
        local result = testFunc()
        if result == false then
            running = false
        end
    end
    showUI()
    screen.flip()
    os.delay(16)
end
